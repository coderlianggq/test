window.members = []
for (var i = 1; i < 45; i++) {
    window.members.push(
      {
          "id":i,
          name:i+"号"
      }
  )
};